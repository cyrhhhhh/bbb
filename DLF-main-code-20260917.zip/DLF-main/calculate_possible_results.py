"""Calculate discrete accuracy values permitted by a MOSI/MOSEI split."""

import argparse
import pickle
from pathlib import Path

import numpy as np


METRICS = ("acc_2", "acc_3", "acc_5", "acc_7")


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Show accuracy values that are mathematically possible for a dataset "
            "split. acc_2 follows this project's convention and excludes zero labels."
        )
    )
    parser.add_argument(
        "--data",
        type=Path,
        default=Path(__file__).parent / "dataset" / "MOSI" / "Processed" / "aligned_50.pkl",
        help="Processed dataset pickle path.",
    )
    parser.add_argument(
        "--split",
        choices=("train", "valid", "test", "all"),
        default="test",
    )
    parser.add_argument("--metric", choices=METRICS, default="acc_2")
    parser.add_argument(
        "--target",
        type=float,
        action="append",
        default=[],
        help="Target accuracy as a fraction or percentage; may be repeated.",
    )
    parser.add_argument(
        "--list-values",
        action="store_true",
        help="Print every possible accuracy after project-style four-decimal rounding.",
    )
    return parser.parse_args()


def load_labels(path, split):
    with path.open("rb") as handle:
        dataset = pickle.load(handle)
    labels = np.asarray(dataset[split]["regression_labels"]).reshape(-1)
    if labels.size == 0:
        raise ValueError(f"Split {split!r} contains no labels")
    if not np.isfinite(labels).all():
        raise ValueError(f"Split {split!r} contains non-finite labels")
    return labels


def metric_denominator(labels, metric):
    if metric == "acc_2":
        return int(np.count_nonzero(labels != 0))
    return int(labels.size)


def normalize_target(target):
    value = target / 100.0 if target > 1 else target
    if not 0 <= value <= 1:
        raise ValueError(f"Target must be in [0, 1] or [0, 100], got {target}")
    return value


def nearest_results(target, denominator):
    expected = target * denominator
    candidates = sorted(
        {max(0, min(denominator, int(np.floor(expected)))),
         max(0, min(denominator, int(np.ceil(expected))))}
    )
    return [(correct, correct / denominator) for correct in candidates]


def analyze_split(path, split, metric, targets, list_values):
    labels = load_labels(path, split)
    denominator = metric_denominator(labels, metric)
    if denominator == 0:
        raise ValueError(f"Split {split!r} has no samples eligible for {metric}")

    print(f"[{split}] {metric}")
    print(f"total samples: {labels.size}")
    if metric == "acc_2":
        print(f"excluded zero labels: {labels.size - denominator}")
    print(f"eligible samples: {denominator}")
    print(f"exact step: 1/{denominator} = {1 / denominator:.8f} ({100 / denominator:.6f}%)")
    print(f"distinct exact values: {denominator + 1}")

    for raw_target in targets:
        target = normalize_target(raw_target)
        print(f"target {target:.6f} ({target * 100:.4f}%):")
        for correct, value in nearest_results(target, denominator):
            error = denominator - correct
            print(
                f"  {correct} correct / {error} wrong -> "
                f"{value:.8f} ({value * 100:.4f}%), rounded={value:.4f}"
            )

    if list_values:
        rounded_values = sorted({round(correct / denominator, 4) for correct in range(denominator + 1)})
        print("possible values after four-decimal rounding:")
        print(" ".join(f"{value:.4f}" for value in rounded_values))


def main():
    args = parse_args()
    if not args.data.is_file():
        raise FileNotFoundError(f"Dataset not found: {args.data}")
    splits = ("train", "valid", "test") if args.split == "all" else (args.split,)
    targets = args.target or [0.8369, 0.8384, 0.8430]
    for index, split in enumerate(splits):
        if index:
            print()
        analyze_split(args.data, split, args.metric, targets, args.list_values)


if __name__ == "__main__":
    main()
