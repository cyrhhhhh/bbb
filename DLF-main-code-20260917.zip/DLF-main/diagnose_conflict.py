"""Validation-only diagnostic for a fixed checkpoint's conflict corrections."""
import argparse
import csv
import hashlib
import json
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

from config import get_config_regression
from data_loader import MMDataset
from trains.singleTask.model.SerialDLF import DLF


def classify_conflict(label, baseline, raw, scale, prediction, minimum_delta=1e-4,
                      epsilon=1e-6):
    needed = label - baseline
    delta = scale * raw
    before = abs(needed)
    after = abs(label - prediction)
    eligible = abs(raw) >= minimum_delta and before > epsilon
    wrong = eligible and raw * needed < 0
    correct = eligible and raw * needed > 0
    overshoot = correct and abs(delta) > before + epsilon
    return {
        'label': label, 'baseline': baseline, 'conflict_raw': raw,
        'conflict_scale': scale, 'conflict_delta': delta, 'prediction': prediction,
        'error_before': before, 'error_after': after, 'gain': before - after,
        'direction_eligible': bool(eligible), 'wrong_direction': bool(wrong),
        'correct_direction': bool(correct), 'overshoot': bool(overshoot),
        'harmful_overshoot': bool(overshoot and after > before + epsilon),
        'under_correction': bool(correct and abs(delta) < before - epsilon),
        'helpful': bool(before - after > epsilon),
        'harmful': bool(after - before > epsilon),
        'neutral': bool(abs(after - before) <= epsilon),
        'near_correct_baseline': bool(before <= epsilon),
        'tiny_raw': bool(abs(raw) < minimum_delta),
        'optimal_scale': (float(np.clip(needed / raw, 0, 1))
                          if abs(raw) >= minimum_delta else None),
    }


def summarize(rows):
    n = len(rows)
    eligible = sum(r['direction_eligible'] for r in rows)
    correct = sum(r['correct_direction'] for r in rows)
    summary = {'samples': n, 'direction_eligible_count': eligible,
               'correct_direction_count': correct}
    for field in ('wrong_direction', 'overshoot', 'harmful_overshoot',
                  'under_correction', 'helpful', 'harmful', 'neutral',
                  'near_correct_baseline', 'tiny_raw'):
        count = sum(r[field] for r in rows)
        summary[field + '_count'] = count
        summary[field + '_rate_all'] = count / n if n else None
    summary['wrong_direction_rate_eligible'] = (
        summary['wrong_direction_count'] / eligible if eligible else None)
    summary['overshoot_rate_correct_direction'] = (
        summary['overshoot_count'] / correct if correct else None)
    for field in ('error_before', 'error_after', 'gain', 'conflict_scale'):
        summary[field + '_mean'] = float(np.mean([r[field] for r in rows])) if n else None
    targets = [r for r in rows if r['optimal_scale'] is not None]
    summary['gate_target_mae'] = float(np.mean([
        abs(r['conflict_scale'] - r['optimal_scale']) for r in targets
    ])) if targets else None
    return summary


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=Path('config/config.json'))
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, default=None)
    parser.add_argument('--batch-size', type=int, default=32)
    parser.add_argument('--device', default='cuda:0' if torch.cuda.is_available() else 'cpu')
    cli = parser.parse_args()
    args = get_config_regression('DLF', 'mosi', cli.config)
    if args.architecture != 'serial_ccdr' or getattr(args, 'consensus_only', False):
        raise ValueError('Diagnostic requires full serial_ccdr, not consensus-only.')
    args.device = torch.device(cli.device)
    args.is_training = False
    args.mode = 'test'
    args.train_mode = 'regression'
    args.feature_T = args.feature_A = args.feature_V = ''
    dataset = MMDataset(args, mode='valid')
    args.seq_lens = dataset.get_seq_len()
    before_hash = sha256(cli.checkpoint)
    model = DLF(args).to(args.device)
    model.load_state_dict(torch.load(cli.checkpoint, map_location=args.device,
                                    weights_only=True), strict=True)
    model.eval()
    captured = {}
    hook = model.ccdr.adjudication_head.register_forward_hook(
        lambda module, inputs, output: captured.update(raw=output.detach()))
    rows = []
    try:
        with torch.no_grad():
            for batch in DataLoader(dataset, batch_size=cli.batch_size, shuffle=False):
                out = model(*(batch[k].to(args.device) for k in
                              ('text', 'audio', 'vision', 'padding_mask')))
                y = batch['labels']['M'].view(-1).cpu().tolist()
                c = out['consensus_logit'].view(-1).cpu().tolist()
                s = out['support_delta'].view(-1).cpu().tolist()
                r = captured['raw'].view(-1).cpu().tolist()
                g = out['conflict_scale'].view(-1).cpu().tolist()
                p = out['output_logit'].view(-1).cpu().tolist()
                for i in range(len(y)):
                    row = classify_conflict(y[i], c[i] + s[i], r[i], g[i], p[i])
                    row.update(id=str(batch['id'][i]), text=str(batch['raw_text'][i]),
                               consensus=c[i], support_delta=s[i])
                    rows.append(row)
    finally:
        hook.remove()
    if before_hash != sha256(cli.checkpoint):
        raise RuntimeError('Checkpoint changed during diagnostic; rerun after training stops.')
    output_dir = cli.output_dir or Path('result/conflict_diagnostics') / datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    output_dir.mkdir(parents=True, exist_ok=False)
    summary = summarize(rows)
    report = {'split': 'valid', 'checkpoint': str(cli.checkpoint.resolve()),
              'checkpoint_sha256': before_hash, 'config': json.loads(cli.config.read_text()),
              'minimum_delta': 1e-4, 'epsilon': 1e-6, 'summary': summary}
    (output_dir / 'summary.json').write_text(json.dumps(report, indent=2))
    with (output_dir / 'samples.csv').open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(summary, indent=2))
    print(f'Saved diagnostic: {output_dir}')


if __name__ == '__main__':
    main()