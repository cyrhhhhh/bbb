import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
from unittest.mock import patch

import torch

from trains.singleTask.DLF import DLF as Trainer


class DirectionLossTest(unittest.TestCase):
    def output(self):
        return {
            'consensus_logit': torch.tensor([1., -1., 0.05], requires_grad=True),
            'support_delta': torch.tensor([-0.4, 0.2, -5.], requires_grad=True),
            'conflict_delta': torch.tensor([0.2, -0.4, 5.], requires_grad=True),
            'output_logit': torch.zeros(3),
        }

    def test_default_matches_legacy_direction_formula(self):
        out = self.output()
        routing = torch.tensor([[0.2] * 3, [0.6] * 3, [1.] * 3])
        c = out['consensus_logit'].detach()
        valid = c.abs() > 0.1
        expected = (
            torch.relu(-c.sign() * out['support_delta'])[valid].mean()
            + (routing.mean(dim=1) * torch.relu(c.sign() * out['conflict_delta']))[valid].mean()
        )
        self.assertTrue(torch.equal(Trainer._direction_effect_loss(out, routing), expected))
        self.assertAlmostEqual(expected.item(), 0.44, places=6)

    def test_removes_only_support_gradient(self):
        out = self.output()
        routing = torch.tensor([[0.2] * 3, [0.6] * 3, [1.] * 3], requires_grad=True)
        new = Trainer._direction_effect_loss(out, routing, False)
        self.assertAlmostEqual(new.item(), 0.14, places=6)
        new.backward()
        conflict_grad = out['conflict_delta'].grad.clone()
        self.assertIsNone(out['support_delta'].grad)
        self.assertIsNone(out['consensus_logit'].grad)
        self.assertIsNone(routing.grad)
        out['conflict_delta'].grad = None
        Trainer._direction_effect_loss(out, routing, True).backward()
        self.assertTrue(torch.equal(out['conflict_delta'].grad, conflict_grad))
        self.assertGreater(out['support_delta'].grad.abs().sum().item(), 0.)

    def test_useful_attenuation_has_no_sign_penalty(self):
        # Consensus overstates the true sentiment; a negative correction helps.
        out = {
            'consensus_logit': torch.tensor([1.]),
            'support_delta': torch.tensor([-0.8]),
            'conflict_delta': torch.tensor([0.]),
            'output_logit': torch.zeros(1),
        }
        routing = torch.ones(1, 3)
        self.assertGreater(Trainer._direction_effect_loss(out, routing, True).item(), 0.)
        self.assertEqual(Trainer._direction_effect_loss(out, routing, False).item(), 0.)

    def test_near_zero_consensus_keeps_original_mask(self):
        out = self.output()
        out['consensus_logit'] = torch.tensor([-0.1, 0., 0.1])
        for enabled in (True, False):
            loss = Trainer._direction_effect_loss(out, torch.ones(3, 3), enabled)
            self.assertTrue(torch.isfinite(loss))
            self.assertEqual(loss.item(), 0.)


class DirectionArtifactTest(unittest.TestCase):
    def test_new_variant_does_not_overwrite_old_artifacts(self):
        import run

        with TemporaryDirectory() as directory:
            root = Path(directory)
            for enabled in (True, False):
                args = SimpleNamespace(
                    model_name='DLF', dataset_name='mosi', architecture='serial_ccdr',
                    input_level='sequence', use_support_correction=True,
                    cred_support_gate_weight=0.05, cred_support_gate_mode='continuous',
                    use_support_direction_constraint=enabled,
                )
                # EasyDict is the actual config type; keep unrelated configuration out.
                from easydict import EasyDict
                config = EasyDict(vars(args))
                with patch.object(run, 'get_config_regression', return_value=config), \
                     patch.object(run, '_set_logger', return_value=run.logger), \
                     patch.object(run, 'assign_gpu', return_value='cpu'), \
                     patch.object(run, 'setup_seed'), \
                     patch.object(run, '_run', return_value={'MAE': 0.5}) as execute:
                    run.DLF_run(
                        'DLF', 'mosi', config_file=str(Path(__file__).resolve().parents[1] / 'config/config.json'),
                        seeds=[1111], model_save_dir=str(root / 'pt'),
                        res_save_dir=str(root / 'result'), log_dir=str(root / 'log'),
                        is_training=True, mode='train',
                    )
                suffix = '' if enabled else '-no-support-direction'
                expected = f'DLF-mosi-serial-ccdr-continuous-gated-support{suffix}.pth'
                self.assertEqual(execute.call_args.args[0].model_save_path.name, expected)
                csv_suffix = '' if enabled else '_no_support_direction'
                self.assertTrue((root / 'result/normal' /
                    f'mosi_serial_ccdr_continuous_gated_support{csv_suffix}.csv').is_file())

if __name__ == '__main__':
    unittest.main()