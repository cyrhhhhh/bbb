# Serial Disentanglement and CCDR

## Inference Architecture

```mermaid
flowchart TB
    T[Text tokens] --> BERT[BERT encoder]
    A[Acoustic features] --> PA[Audio Conv1d]
    V[Visual features] --> PV[Vision Conv1d]
    BERT --> PT[Text Conv1d]

    PT --> SL[Text-private encoder]
    PA --> SA[Audio-private encoder]
    PV --> SV[Vision-private encoder]
    PT --> SC[Shared Transformer encoder]
    PA --> SC
    PV --> SC

    SL --> SPL[Private text s_l]
    SA --> SPA[Private audio s_a]
    SV --> SPV[Private vision s_v]
    SC --> SHL[Shared text c_l]
    SC --> SHA[Shared audio c_a]
    SC --> SHV[Shared vision c_v]

    SPL --> CRED[CRED decomposition]
    SPA --> CRED
    SPV --> CRED
    SHL --> CRED
    SHA --> CRED
    SHV --> CRED

    CRED --> CONS[Consensus evidence]
    CRED --> SUP[Supporting evidence]
    CRED --> CONF[Conflicting evidence]
    CONS --> YC[Consensus score]
    SUP --> DS[Support correction]
    CONF --> EATTN[Language-anchored evidence attention]
    EATTN --> DR[Conflict correction]

    YC --> SUM((+))
    DS --> SUM
    DR --> SUM
    SUM --> Y[Final sentiment score]

    SHL -. training only .-> PL[Text shared probe]
    SHA -. training only .-> PAUX[Audio shared probe]
    SHV -. training only .-> PVUX[Vision shared probe]
    SPL -. training only .-> REC[Reconstruction and separation losses]
    SPA -. training only .-> REC
    SPV -. training only .-> REC
    SHL -. training only .-> REC
    SHA -. training only .-> REC
    SHV -. training only .-> REC
```

The architecture is strictly serial. The first stage separates each modality
into shared and private representations. CCDR then performs a second,
semantically distinct decomposition into consensus, supporting, and conflicting
evidence. The original parallel DLF anchor prediction is not part of this path.

The final prediction is

$$
\hat{y}=\hat{y}_{\mathrm{consensus}}
+\Delta_{\mathrm{support}}
+\Delta_{\mathrm{conflict}}.
$$

The three shared-modality probes are training-only auxiliary heads. They
supervise the shared representations and provide a detached disagreement target
for CCDR routing, but they do not contribute directly to the final prediction.

## Training Objectives

```mermaid
flowchart LR
    MAIN[Final-output L1] --> TOTAL[Total loss]
    SHARED[Shared-probe L1] --> TOTAL
    CONS[Consensus L1] --> TOTAL
    RECON[Input and private reconstruction] --> TOTAL
    SEP[Shared-private separation] --> TOTAL
    SIM[Cross-modal shared similarity] --> TOTAL
    CREC[CRED reconstruction] --> TOTAL
    DECOR[Consensus-support-conflict decorrelation] --> TOTAL
    ROUTE[Conflict ranking and routing] --> TOTAL
    EFFECT[Correction-direction constraints] --> TOTAL
```

Padding positions are masked before temporal convolution, throughout the
shared/private Transformer encoders, and inside CCDR pooling and attention.
With sequence length 50 and kernel size 5, the projected sequence length is 46.

## Artifact Compatibility

This model writes checkpoints with the `serial-ccdr` suffix and results to
`mosi_serial_ccdr.csv`. Checkpoints from the previous parallel architecture are
not structurally compatible and must not be loaded into this model.