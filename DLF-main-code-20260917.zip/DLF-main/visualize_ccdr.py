"""Visualize token-level CCDR routing and conflict adjudication."""

import argparse
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["text.parse_math"] = False
import matplotlib.pyplot as plt
import numpy as np
import torch
from torch.utils.data import DataLoader

from config import get_config_regression
from data_loader import MMDataset
from trains.singleTask.model.SerialDLF import DLF


MODALITIES = ("language", "audio", "vision")


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=Path("config/config.json"))
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=Path("pt/DLF-mosi-serial-ccdr.pth"),
    )
    parser.add_argument("--split", choices=("train", "valid", "test"), default="test")
    parser.add_argument("--top-k", type=int, default=12)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--output-dir", type=Path, default=Path("result/ccdr_visualizations"))
    parser.add_argument("--device", default="cuda:0" if torch.cuda.is_available() else "cpu")
    return parser.parse_args()


def projected_token_labels(tokenizer, input_ids, kernel_size, output_length):
    tokens = tokenizer.convert_ids_to_tokens(input_ids.tolist())
    labels = []
    special_tokens = set(tokenizer.all_special_tokens)
    for index in range(output_length):
        window = [
            token for token in tokens[index:index + kernel_size]
            if token not in special_tokens
        ]
        labels.append(" ".join(window) if window else f"pos-{index}")
    return labels


def extract_sample(output, batch_index, padding_masks):
    route_conflict = []
    for gate, mask in zip(output["route_gates"], padding_masks):
        valid = ~mask[batch_index]
        route_conflict.append(
            (1.0 - gate[:, batch_index].mean(dim=-1))[valid].detach().cpu().numpy()
        )

    attention = output["evidence_attention"][batch_index].mean(dim=0)
    audio_length = output["route_gates"][1].size(0)
    visual_length = output["route_gates"][2].size(0)
    audio_valid = ~padding_masks[1][batch_index]
    visual_valid = ~padding_masks[2][batch_index]
    attention_rows = np.stack([
        attention[0, :audio_length][audio_valid].detach().cpu().numpy(),
        attention[0, audio_length:audio_length + visual_length][visual_valid].detach().cpu().numpy(),
        attention[1, :audio_length][audio_valid].detach().cpu().numpy(),
        attention[1, audio_length:audio_length + visual_length][visual_valid].detach().cpu().numpy(),
    ])
    conflict_score = float(np.mean([
        route_conflict[1].mean(), route_conflict[2].mean()
    ]))
    query_divergence = float(np.mean(np.abs(np.concatenate([
        attention_rows[0] - attention_rows[2],
        attention_rows[1] - attention_rows[3],
    ]))))
    return route_conflict, attention_rows, conflict_score, query_divergence


def pad_rows(rows, fill_value=np.nan):
    width = max(len(row) for row in rows)
    matrix = np.full((len(rows), width), fill_value, dtype=np.float32)
    for index, row in enumerate(rows):
        matrix[index, :len(row)] = row
    return matrix


def escape_math_text(text):
    return str(text).replace("$", r"\$")


def draw_sample(sample, output_path):
    route_matrix = pad_rows(sample["route_conflict"])
    attention_matrix = sample["attention"]
    labels = [
        escape_math_text(label)
        for label in sample["token_labels"][:route_matrix.shape[1]]
    ]

    figure, axes = plt.subplots(2, 1, figsize=(max(12, len(labels) * 0.34), 6.5))
    route_image = axes[0].imshow(route_matrix, aspect="auto", vmin=0.0, vmax=1.0, cmap="magma")
    axes[0].set_yticks(range(3), MODALITIES)
    axes[0].set_xticks(range(len(labels)), labels, rotation=70, ha="right", fontsize=7)
    axes[0].set_title("Token-level conflict routing (1 - route gate)")
    figure.colorbar(route_image, ax=axes[0], fraction=0.02, pad=0.01)

    attention_image = axes[1].imshow(attention_matrix, aspect="auto", cmap="viridis")
    axes[1].set_yticks(
        range(4),
        ("support→audio", "support→vision", "reverse→audio", "reverse→vision"),
    )
    axes[1].set_xlabel("Projected aligned position")
    axes[1].set_title("Language-anchored conflict evidence attention")
    figure.colorbar(attention_image, ax=axes[1], fraction=0.02, pad=0.01)

    figure.suptitle(
        f"{sample['id']} | true={sample['label']:.3f} | pred={sample['prediction']:.3f} | "
        f"conflict={sample['conflict_score']:.3f} | query diff={sample['query_divergence']:.5f}\n"
        f"{escape_math_text(sample['raw_text'])}",
        fontsize=10,
    )
    figure.tight_layout()
    figure.savefig(output_path, dpi=180, bbox_inches="tight")
    plt.close(figure)


def main():
    cli = parse_args()
    args = get_config_regression("DLF", "mosi", cli.config)
    args.is_training = False
    args.mode = "test"
    args.train_mode = "regression"
    args.feature_T = args.feature_A = args.feature_V = ""
    args.device = torch.device(cli.device)

    dataset = MMDataset(args, mode=cli.split)
    args.seq_lens = dataset.get_seq_len()
    model = DLF(args).to(args.device)
    model.load_state_dict(torch.load(cli.checkpoint, map_location=args.device), strict=True)
    model.eval()
    loader = DataLoader(dataset, batch_size=cli.batch_size, shuffle=False)
    tokenizer = model.text_model.get_tokenizer()
    samples = []

    with torch.no_grad():
        for batch in loader:
            text = batch["text"].to(args.device)
            audio = batch["audio"].to(args.device)
            vision = batch["vision"].to(args.device)
            padding_mask = batch["padding_mask"].to(args.device)
            output = model(text, audio, vision, padding_mask)
            projected_masks = output["projected_padding_masks"]

            for batch_index in range(text.size(0)):
                route_conflict, attention, score, query_divergence = extract_sample(
                    output, batch_index, projected_masks
                )
                support_delta = float(output["support_delta"][batch_index].item())
                conflict_delta = float(output["conflict_delta"][batch_index].item())
                branch_magnitude = abs(support_delta) + abs(conflict_delta)
                labels = projected_token_labels(
                    tokenizer,
                    text[batch_index, 0].cpu(),
                    args.conv1d_kernel_size_l,
                    len(route_conflict[0]),
                )
                samples.append({
                    "id": str(batch["id"][batch_index]),
                    "raw_text": str(batch["raw_text"][batch_index]),
                    "label": float(batch["labels"]["M"][batch_index].item()),
                    "prediction": float(output["output_logit"][batch_index].item()),
                    "consensus": float(output["consensus_logit"][batch_index].item()),
                    "support_delta": support_delta,
                    "conflict_delta": conflict_delta,
                    "support_scale": float(output["support_scale"][batch_index].item()),
                    "support_fraction": (
                        abs(support_delta) / branch_magnitude
                        if branch_magnitude > 0.0 else 0.0
                    ),
                    "conflict_score": score,
                    "query_divergence": query_divergence,
                    "route_conflict": route_conflict,
                    "attention": attention,
                    "token_labels": labels,
                })

    selected = sorted(samples, key=lambda item: item["conflict_score"], reverse=True)[:cli.top_k]
    cli.output_dir.mkdir(parents=True, exist_ok=True)
    fields = (
        "rank", "id", "raw_text", "label", "prediction", "consensus",
        "support_delta", "conflict_delta", "support_scale",
        "support_fraction", "conflict_score",
        "query_divergence", "figure",
    )
    with (cli.output_dir / "summary.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for rank, sample in enumerate(selected, start=1):
            safe_id = "".join(character if character.isalnum() or character in "-_" else "_" for character in sample["id"])
            figure_name = f"{rank:02d}_{safe_id}.png"
            draw_sample(sample, cli.output_dir / figure_name)
            row = {key: sample[key] for key in fields if key in sample}
            row["rank"] = rank
            row["figure"] = figure_name
            writer.writerow(row)

    print(f"Saved {len(selected)} visualizations to {cli.output_dir}")


if __name__ == "__main__":
    main()