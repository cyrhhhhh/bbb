# 代码、论文与模型图一致性审查

审查日期：2026-09-17。结论：**当前图不通过技术一致性检查，未插入正文。** 文稿已修正能由源码确定的问题，并以占位框替换原来的未核准框架图。保留原始上传代码，没有为迎合图示而改变模型。

## 核对范围及限制

核对当前 `config/config.json` 的 `architecture=serial_ccdr`、`run.py`、`train.py`、`data_loader.py`、`trains/singleTask/model/SerialDLF.py`、`CCDR.py`、`trains/singleTask/DLF.py`、相关 attention 实现、现有测试、文章 `main.tex` 及用户上传图片。此审查以当前配置为准，不以旧的 parallel DLF 为准。

尝试运行 `python -m unittest discover -s tests -v`，测试模块导入即因 `ModuleNotFoundError: No module named 'torch'` 中断，不能称为测试通过，也不是已经验证模型失败。未提供数据集、已训练权重和实验结果，无法验证精度、稳定性或语义可解释性。论文成功编译为 14 页；检查了渲染页面及日志，未发现未定义引用或 overfull 排版警告。

## 一、图中必须修正的问题

| 优先级 | 位置 | 问题 | 与代码一致的画法 |
|---|---|---|---|
| 高 | (a) Shared Encoder | 一个共享编码器同时输出 shared/private，不对应实现 | 共享编码器 E_c 权重跨模态复用；私有编码器 E_l/E_a/E_v 各自独立。输入分别进入两路 |
| 高 | (a) Language/BERT | 遗漏文本的 Conv1D 投影，易把 768 维直接送入 50 维 backbone | Text → BERT → Conv1D_l → Z_l；音频与视觉是预提取特征输入，不是端到端原始波形／图像编码 |
| 高 | (a) Consensus Extraction | 看起来直接产生 Q、U、K，缺少 residual 构造与路由 | Q 来自 donor attention + target residual；R 来自 [S; C−Q] 投影；U/K 来自 G 和 1−G 对 R 的互补门控 |
| 高 | (b) 减号 | donor p 直接接减法，实际应为目标 shared 减去其 consensus | 先逐 donor 做 attention，再按 cosine-softmax 权重聚合；Q_m=LN(C_m+ΣαD)，偏差为 C_m−Q_m |
| 高 | (b) α 公式 | 把 token attention softmax 与 donor reliability softmax 混成一个量 | attention token 权重和 donor 权重分开；α_mn=softmax_n(cos(C_m,D_mn)/τ) |
| 高 | (b) 残差符号 | 路由接投影后的残差，但 U/K 公式仍用投影前的 R | 统一 R_m=P_m([S_m; C_m−Q_m])，U_m=G_m⊙R_m，K_m=(1−G_m)⊙R_m |
| 高 | (c) Language anchor | 图为 C_L (T×d)，代码用池化后的 language consensus+support，并加 global consensus | H_l=Pool(Q_l+U_l)，A=LN(H_l+Qbar)，q+=p++A，q−=p−−A |
| 高 | (c) evidence attention | 缺少 query 残差与 LayerNorm | E=LN_e(MHA([q+;q−],K_av,K_av)+[q+;q−])，K_av=[K_a;K_v] |
| 高 | (c) 裁决头输入 | [e+;e−;C_L] 不对应代码，且混用序列与向量 | 输入为 [Qbar;H_l;e+;e−]，总维度 4d，输出标量 raw conflict delta |
| 高 | (c) 右下最终公式 | ΔK=βK(e+−e−) 是 d 维向量，无法作为情感标量修正；实现没有此减法 | ΔK=βK·MLP_adj([Qbar;H_l;e+;e−])；βK=sigmoid(MLP_scale([Qbar;Kbar]))，两条并行路径最后相乘 |
| 中 | (a) base/support 头 | 省略必要上下文连接 | yC=head([Qbar;Pool(Q_l)])；support raw 与 scale 都使用 [Qbar;Ubar] |
| 中 | 标签与视觉 | supporting/reversing 看似已被证明；热图无样本出处；图有明显透明边缘杂点 | 标注 query 设计意图；热图注明 schematic，不能冒充实测 attention；终稿使用干净白底和可编辑矢量 |

CRED 输入先经模态专属 shared/specific LayerNorm。为清晰可以在总图省略，但图注及详细图／正文必须说明。对不同角色分别做 attention pooling，先模态内时间池化，再等权平均模态，不是直接拼接所有 token 池化。语言冲突 K_l 不进入 evidence attention，但参与 Kbar，因此仍影响 conflict scale。

## 二、文章已修正

1. 全文把“有界修正量”改为“带门控的修正量”；β∈[0,1] 不保证 raw delta 或最终预测有界。相应消融改名为 Unit correction scales。
2. 补入 evidence attention 的 query residual + LayerNorm；说明 anchor LN 无可学习 affine、evidence LN 有可学习参数。
3. 补充 CRED 输入 LayerNorm；澄清仅 donor 排除目标，Q 仍含目标 C 的残差，不是真正 target-free consensus。
4. 修复 pooling 公式中的 `\\frac` 排版错误；分母改为实际输入模态集合大小，语言单模态池化不除以 3；说明角色 scorer 分离和语言 scorer 共享。
5. 重建损失改为有效元素均值；协方差惩罚加入 1/d²，明确 batch/token 归约；补充 route variance、effect 的 0.1 中性阈值与 detach、support loss 的权重归一化、gate Smooth L1 及 1e−4 阈值。
6. 列明当前为零的 specific-cycle/shared-alignment/role-reconstruction/ranking/delta 权重，避免把定义过的损失误写成启用的损失。
7. 摘要不再用“实验表明”的措辞描述未完成实验；实验章节统一标为计划，保留 TBD，未填入任何虚构结果。
8. validation 分位数划分 test 后不保证三组等人数，已由 thirds 改为 strata，要求报告样本数及同值处理。
9. 明确 +/− query 只是归纳偏置，不能保证真的对应支持／反转；门控数值也不是校准后的可信概率。
10. 补充梯度累积、有效批大小、weight decay、测试集日志及 CSV 单位问题。利益冲突声明改为待作者确认，避免代作者作事实声明。

## 三、代码风险与实验前待办

### 需要优先处理

- **指标单位**：`run.py` 对所有结果乘 100，包括 MAE/Corr/Loss。不是训练公式错误，但直接抄 CSV 会使论文单位错误。建议按指标区分转换并保存原始值；本次未改代码。
- **缺少逐样本输出**：trainer `do_test` 接受 `return_sample_results`，但未实现返回逐样本预测、ID 或 branch outputs；目前结果不足以支持文稿计划的配对 bootstrap、分冲突子集与 correction-effect 分析。需要另外实现导出。
- **全 padding 边界**：`ModalityBalancedAttentionPool` 对全 padding 序列产生全 −inf 的 softmax，未处理；attention 全 masked keys 也需保护。这是静态识别的风险，未运行复现，不能断言现有数据必然触发。数据预检应拒绝无有效 token 的样本。
- **对齐假设**：三模态统一使用文本 padding mask，只有时间长度及预处理对齐时才成立；原始数据未提供，无法确认。零值音视频特征与 padding mask 是不同概念。
- **验证 Loss 按 batch 均值平均**：`do_test` 等权平均各 batch 的平均 L1，最后不足一个 batch 时不等于逐样本 MAE，可能影响 checkpoint 选择。应按 batch 样本数加权；不能凭此断言现有最佳 checkpoint 已有变化。

### 设计限制与效率

- U 和 K 是同一个 R 的互补缩放，U+K=R；不是可证明独立的两种潜变量。协方差正则不保证语义分离，也不等于正交证明。
- effect loss 鼓励 support 与 consensus 同向、conflict 反向，是软约束，可能限制有用的同向冲突修正。需要无方向约束消融。
- 共享 encoder 的权重共享不保证其输出跨模态一致；当前 shared alignment loss 权重为 0，不应写成已实现严格对齐。
- cycle、alignment 的计算路径与 shared probes 仍在 `forward` 中执行，即使对应损失权重为 0 或处于 eval。所谓 training-only 指监督用途，不代表推理实现已跳过计算。效率报告必须基于实际执行路径。
- 每个 epoch 会记录 test 指标，checkpoint 确实依据 validation loss；没有看到自动按 test 选模型，但人工调参应避免参考 test 曲线。
- `train.py` 目前只运行 MOSEI、seed 1111；五 seeds、MOSI 和消融都不是已经完成。
- attention 热图“两个 query 不同”不能证明其中一个是支持、另一个是反转。

## 四、尚未完成的论文审查项

- `elsarticle.cls` 在本环境缺失，当前 PDF 使用源码中的 article fallback；不能称为已验证的 Elsevier 正式模板。最终投稿前需用真正 elsarticle 模板编译并重新检查排版。
- 未逐篇核实所有参考文献的全文、页码和 Table 1 对竞争方法的功能归类；在线检索只能辅助确认部分条目。尤其不能由摘要推断 ECA/TAMSA “绝对没有某机制”。这些比较仍需原论文逐条对证，本文创新性尚未获得独立验证。
- 数据划分、特征预处理、五种子结果、显著性、超参数选择、参数量/FLOPs 都需实验材料证明；当前没有证据支持 SOTA 或冲突子集显著提升。

## 五、供重新绘图使用的核心计算清单

```
Z_l = Conv_l(BERT(text)); Z_a = Conv_a(audio_features); Z_v = Conv_v(visual_features)
C_m = E_c(Z_m); S_m = E_m(Z_m)
C_m, S_m = modality-specific LayerNorm(C_m), LayerNorm(S_m) [within CRED]
D_mn = MHA(C_m, C_n, C_n), n != m
alpha_mn = softmax_over_donors(cos(C_m,D_mn)/tau)
Q_m = LN(C_m + sum_n alpha_mn * D_mn)
R_m = MLP_m([S_m; C_m-Q_m])
G_m = 0.5 * (sigmoid(router_m([R_m;Q_m])/tau) + agreement_m)
U_m = G_m * R_m; K_m = (1-G_m) * R_m
Qbar, Ubar, Kbar = separate modality-balanced attention pools
H_l = language_pool(Q_l+U_l); Q_l_star = language_pool(Q_l)
A = LN_without_affine(H_l+Qbar)
q_plus = p_plus+A; q_minus = p_minus-A
E = LN_e(MHA([q_plus;q_minus], [K_a;K_v], [K_a;K_v])+[q_plus;q_minus])
y_C = MLP_C([Qbar;Q_l_star])
delta_S = sigmoid(scale_S([Qbar;Ubar])) * MLP_S([Qbar;Ubar])
delta_K = sigmoid(scale_K([Qbar;Kbar])) * MLP_adj([Qbar;H_l;e_plus;e_minus])
y_hat = y_C + delta_S + delta_K
```

这里的代码式清单用于精确表达计算依赖，不代替论文模型图。最终插图应按此重新构造矢量图并逐线核对；本次没有插入错误图片。
